/**
 * nie jestem autorem tego skryptu,
 * ja tylko go przenioslem do osobnego pliku
 * bo sklejanie stringow w javie to slaby pomysl...
 * (po prosotu ciezko sie czyta i wprowadza zmiany)
 */
function capslockme(insertedValue, myvar, keepCase, caretPos) {
	var isUppercase = false;
	var znak = '';
	if (myvar.length <= 2) {
		isUppercase = true;
	} else {
		for ( var it = caretPos !== undefined ? caretPos : myvar.length - 1; it >= 0; it--) {
			znak = myvar.charAt(it);
			var zAscii = znak.charCodeAt();
			if (zAscii != 32 && zAscii != 13 && zAscii != 10 && zAscii != 160 && zAscii != 9) {
				isUppercase = myvar.charAt(it) == '.' || myvar.charAt(it-1) == '.' || (myvar.charAt(it-1) == ' ' && myvar.charAt(it-2) == '.');
				break;
			}
		}
	}
	if (!keepCase) {
		insertedValue = insertedValue.toLowerCase();
		if (isUppercase) {
			insertedValue = insertedValue.charAt(0).toUpperCase() + insertedValue.substr(1);
		}
	}
	return insertedValue;
}

function insertAtCursor(myField, myValue) {
	if (document.selection) {
		myField.focus();
		var sel = document.selection.createRange();
		sel.text = myValue;
	} else if (myField.selectionStart || myField.selectionStart == '0') {
		var scrollRevert = myField.scrollTop;
		var startPos = myField.selectionStart;
		var endPos = myField.selectionEnd;
		myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);
		myField.scrollTop = scrollRevert;
		myField.setSelectionRange(startPos + myValue.length, startPos + myValue.length);
	} else {
		myField.value += myValue;
	}
}

function autoresizing(t){
    t.style.height = '75px';
    t.style.height = (t.scrollHeight) + 'px';
}

function setAccKeyText(insertedValue, textArea, keepCase) {
	var wstaw = true;
	if (textArea.getAttribute('maxlength')) {
		if (textArea.getAttribute('maxlength') < insertedValue.length + textArea.value.length) {
			wstaw = false;
			alert('Wprowadzany tekst jest zbyt d�ugi');
		}
	}
	if (wstaw) {
		var myvar = new String(textArea.value);
		var caretPos = textArea.selectionStart;
		if (caretPos === undefined) {
			var Sel = document.selection.createRange();
			Sel.moveStart('character', -textArea.value.length);
			caretPos = Sel.text.length;
		}
		insertAtCursor(textArea, capslockme(insertedValue, myvar, keepCase, caretPos));
		textArea.focus();
		autoresizing(textArea);
	}
}

function setAccKeyTextFCK(insertedValue, fckFieldName, keepCase) {
	var oEditor = CKEDITOR.instances[fckFieldName];
	if (oEditor.mode == 'wysiwyg') {
		var data = new String(oEditor.getData());
		var element = CKEDITOR.dom.element.createFromHtml('<div>' + data + '</div>');
		var myvar = element.getText();
		oEditor.insertHtml(capslockme(insertedValue.split('\t').join('&nbsp;&nbsp;&nbsp;&nbsp;').split('\r').join('<br/>'), myvar, keepCase));
	}
}

if (document.all) {
	document.onkeyup = specjalnieDlaIE;
}
function specjalnieDlaIE() {
	var changingElement = event.srcElement;
	if (changingElement.type == 'textarea') {
		skrotReplaceKey(changingElement);
	}
}

function skrotReplaceKey(textarea) {
	var startPos = 0;
	var endPos = 0;
	var taValue = '';
	if (document.selection != undefined) { // ustawienie danych dla IE
		textarea.focus();
		var r = document.selection.createRange();
		var re = textarea.createTextRange(), rc = re.duplicate();
		re.moveToBookmark(r.getBookmark());
		rc.setEndPoint('EndToStart', re);
		taValue = rc.text.replace(/\r?\n|\r/g, '\n');// podmiana podw�jnego znaku nowej linii
		endPos = taValue.length;
	} else {// pozosta�e
		taValue = textarea.value.replace(/\r?\n|\r/g, '\n');// podmiana podw�jnego znaku nowej linii
		endPos = textarea.selectionEnd;
	}
	startPos = endPos;
	var nlIdx = taValue.lastIndexOf('\n', endPos - 1);
	var wsIdx = taValue.lastIndexOf(' ', endPos - 2);
	var lastWord = taValue.substring( (wsIdx > nlIdx ? wsIdx : nlIdx) + 1, endPos); // okreslenie ostatniego s�owa (od nowej linii/spacji)
	nlIdx = null;
	wsIdx = null;
	var len = lastWord.length;
	if (len > 1 && lastWord.slice(len - 1, len) == ' ') { // d�ugo�� s�owa > 1 i ko�czy si� spacj�.
		lastWord = lastWord.slice(0, len - 1);
		var map = window['skroty_' + textarea.getAttribute('name')]; // wyszukanie mapy ze skrotami dla pola
		if (map != null && map[lastWord]) { // znaleziono skr�t
		// okre�lenie nowego zaznaczenia dla textarea i skorzystanie z metody podstawienia.
			if (r != null && re != null && rc != null) {
				rc.collapse(true);
				rc.moveEnd('character', startPos);
				rc.moveStart('character', startPos - len);
				rc.select();
			} else {
				textarea.selectionEnd = startPos;
				textarea.selectionStart = startPos - len;
			}
			// insertAtCursor(textarea, map[lastWord]+' ');
			setAccKeyText(map[lastWord].tekst + ' ', textarea, map[lastWord].zwl);
		}
		map = null;
	}
	len = null;
	lastWord = null;
}
