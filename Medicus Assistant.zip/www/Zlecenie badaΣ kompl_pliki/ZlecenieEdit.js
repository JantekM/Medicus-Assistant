"use strict";

var bpTypUmowy;

function dodajKosztBp(id) {
	var re, m, elemCena, cenaBp, elemKzbp;
	elemCena = document.getElementById('cena_'+id);
	if (elemCena) {
		re = /^(?:\D*)(\d+(?:[\.,]{1}\d+)?)(?:\D*)$/;
		m = re.exec(elemCena.innerText);
		cenaBp = +(m[1].replace(',', '.'));
		
		re = /^(\d+(?:[\.,]{1}\d+)?)(\D*)$/;
		
		elemKzbp = document.getElementById('tk1-kom');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) + cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk1-kok');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) + cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk1-kop');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) + cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk2-row-kakzbp');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) + cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk2-row-kzbpr');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) + cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
	}
}

function odejmijKosztBp(id) {
	var re, m, elemCena, cenaBp, elemKzbp;
	elemCena = document.getElementById('cena_'+id);
	if (elemCena) {
		re = /^(?:\D*)(\d+(?:[\.,]{1}\d+)?)(?:\D*)$/;
		m = re.exec(elemCena.innerText);
		cenaBp = +(m[1].replace(',', '.'));
		
		re = /^(\d+(?:[\.,]{1}\d+)?)(\D*)$/;
		
		elemKzbp = document.getElementById('tk1-kom');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) - cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk1-kok');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) - cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk1-kop');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) - cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk2-row-kakzbp');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) - cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
		
		elemKzbp = document.getElementById('tk2-row-kzbpr');
		m = re.exec(elemKzbp.innerText);
		elemKzbp.innerText = (+(m[1].replace(',', '.')) - cenaBp).toLocaleString('pl-PL',
			{minimumFractionDigits: 2, maximumFractionDigits: 2}) + m[2];
	}
}

function uaktualnijKosztZbp(e) {
	var cbWyk = e.target,
		re = /^(?:\D+)(\d+)$/, m = re.exec(e.target.id);
		
	if (cbWyk.checked) {
		cbWyk.setAttribute('uwzg', 'tak');
		dodajKosztBp(m[1]);
		
	} else {
		cbWyk.removeAttribute('uwzg');
		odejmijKosztBp(m[1]);
	}
}

window.onload = function() {
	var elemTu = document.getElementById('bp_typ_umowy');
	if (elemTu) bpTypUmowy = elemTu.value;
	if (bpTypUmowy && bpTypUmowy == 'U') {
		var cbArr = document.querySelectorAll('input[id^="wykonanie_poz_pak_"]'),
			len = cbArr.length | 0, i;
		for (i = 0; i < len; i++) {
			cbArr[i].onchange = uaktualnijKosztZbp;
			if (cbArr[i].checked) {
				var re = /^(?:\D+)(\d+)$/, m = re.exec(cbArr[i].id);
				cbArr[i].setAttribute('uwzg', 'tak');
				dodajKosztBp(m[1]);
			}
		}
		
		cbArr = document.querySelectorAll('input[id^="wykonanie_poz_cito_pak_"]'),
		len = cbArr.length | 0;
		for (i = 0; i < len; i++) {
			cbArr[i].addEventListener('change', function(e) {
				var re = /^(?:\D+)(\d+)$/, m = re.exec(e.target.id),
					cbWyk = document.getElementById('wykonanie_poz_pak_'+m[1]);
				if (e.target.checked && cbWyk && !cbWyk.hasAttribute('uwzg')) {
					cbWyk.setAttribute('uwzg', 'tak');
					dodajKosztBp(m[1]);
				}
			});
		}
	}
}


$(document).ready(function() {
    zlecenieImmunoUkryjPokaz();
	hideTextareaOnLoadAndAddChange();
	addUncheckCitoWhenUncheckWykonanie();
});

function zlecenieImmunoUkryjPokaz() {
    if($('select[name=skierowanie_typ_procedury]').val() === 'BAD_IMMUN'){
        const dawka = '#' + get_podano_dawka_field().name + '_all';
        const informacja = '#' + get_podano_info_field().name + '_all';
        const dataPodania = $("span:contains('data podania')").filter(function(obj) {
            return $(this).attr('id').endsWith("_all");
        });
        if (get_podano_immun_field().value === 'ZLEC_POD_IMMUNO_T'){
            $(dawka).show();
            $(informacja).show();
            $(dataPodania).show();
        } else {
            $(dawka).hide();
            $(informacja).hide();
            $(dataPodania).hide();
        }
    }
}

function hideTextareaOnLoadAndAddChange() {
	$('textarea[name^="temp_wykonanie_poz_pak_"]').each(function () {
		let id = $(this).attr('name').split('_')[4];

		let input = $('input[name^="wykonanie_poz_pak_'+id+'"]');
		input.on('change', function () {
			toggleTextarea(id);
		});

		if (input.prop('checked')) {
			$(this).parent().click();
		} else {
			toggleTextarea(id);
		}
	})
}

function toggleTextarea(id) {
	$('textarea[name^="temp_wykonanie_poz_pak_'+id+'_description"]').parent().toggle();
}

function checkWykonanieWhenCito(id) {
	let input = $('input[name^="wykonanie_poz_pak_' + id + '"]');

	if (input.prop("checked")) {
		input.attr("checked", true);
	}
}

function addUncheckCitoWhenUncheckWykonanie() {
	$('input[name^="wykonanie_poz_pak_"]').each(function () {
		let id = $(this).attr('name').split('_')[3];
		$(this).on('change', function () {
			if ($(this).prop('checked')) {
				$('input[name="wykonanie_poz_cito_pak_' + id + '"]').attr("checked", false)
			}
		});
	})
}

function getNazweBadania(id) {
	return $('label[id="wykonanie_poz_pak_'+id+'_sideComment"]').text();
}

function getOstatnioZlecono(id) {
	return $('p[id="ostatnio_zlecono_'+id+'"]').text();
}

function getCena(id) {
	return $('p[id="cena_'+id+'"]').text();
}

function checkBadanie(id) {
	$('input[name="wykonanie_poz_pak_'+id+'"]').prop("checked", true);
}

function uncheckBadanie(id) {
	$('input[name="wykonanie_poz_pak_'+id+'"]').prop("checked", false);
	uncheckBadaniePilne(id);
}

function checkBadaniePilne(id) {
	$('input[name="wykonanie_poz_cito_pak_'+id+'"]').prop("checked", true);
}

function uncheckBadaniePilne(id) {
	$('input[name="wykonanie_poz_cito_pak_'+id+'"]').prop("checked", false);
}

function isBadanieWybrane(id) {
	return $('input[name="wykonanie_poz_pak_'+id+'"]').prop("checked");
}

function isBadaniePilne(id) {
	return $('input[name="wykonanie_poz_cito_pak_'+id+'"]').prop("checked");
}
