$(document).ready(function() {
    let input = $("input[name='temp_show_confirm']");
    if (input.length > 0) {
        let answer = window.confirm(input.val());
        if (answer) {
            $(input).val('true');
            $("button[name='btn_ok']").click();
        }
    }
});

function markCito(numer, zaznaczenie, fullName) {
    if (numer == null) {
        const parts = fullName.split('_');
        numer = parts.pop();
    }
    var citoId = 'wykonanie_poz_cito_pak_' + numer;
    var checkbox = document.getElementById(citoId);
    if (checkbox) {
        checkbox.checked = zaznaczenie;
    }
}

function checkWykonanieWhenCito(id) {
	let input = $('input[name^="wykonanie_poz_pak_' + id + '"]');

	if (input.prop("checked")) {
		input.attr("checked", true);
	}
}
