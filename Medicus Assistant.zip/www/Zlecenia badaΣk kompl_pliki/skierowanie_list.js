function addNewLineInLinks(nodes, skipLast) {
    for (let node of nodes) {
        if (skipLast && node == nodes[nodes.length - 1]) {
            return;
        }
        let sibling = node.nextSibling;
        if (sibling != null && sibling.tagName == null && sibling.nodeName == "#text") {
            if (sibling.data.trim().length > 0) {
                let p = document.createElement("p");
                node.parentNode.insertBefore(p, sibling);
                p.appendChild(sibling);
            } else if (sibling.nextSibling != null && sibling.nextSibling.tagName != null && sibling.nextSibling.tagName.toLowerCase() != "br") {
                let br = document.createElement("br");
                node.parentNode.insertBefore(br, sibling);
            }
        } else if (sibling != null && sibling.tagName != null && sibling.tagName.toLowerCase() != "br") {
            let br = document.createElement("br");
            node.parentNode.insertBefore(br, sibling);
        }
        node.classList.add("brAfter");
    }
}

var checker = null;

function runAfterElementExists(callback) {
    checker = window.setInterval(function () {
        let elements = document.querySelectorAll(".templateListColumnTd.mdl-data-table__cell--non-numeric.templateListSeparatorColumn > a:not(.brAfter)");
        if (elements && elements.length) {
            callback(elements);
        }
    }, 500);
}

runAfterElementExists(function (elements) {
    addNewLineInLinks(elements, true);
});

window.onload = function () {
    clearInterval(checker);
    let elements = document.querySelectorAll(".templateListColumnTd.mdl-data-table__cell--non-numeric.templateListSeparatorColumn > a:not(.brAfter)");
    addNewLineInLinks(elements, false);
}

let warnList = [];
let warnListPending = [];

function addWarningToDOM(warning) {
    let listContainer = $('.warnClass ol');
    if (listContainer.length === 0) {
        let errorContainer = $('.errorFrame');
        if (errorContainer.length > 0) {
            listContainer = createWarnDivAndReturnOl(errorContainer);
        } else {
            return;
        }
    }

    let listItem = document.createElement('li');
    listItem.textContent = warning;
    appendAndSort(listContainer, listItem);
}

function appendAndSort(listContainer, listItem) {
    listContainer.append(listItem);
    let sortedLiList = listContainer.find("li")
        .sort(function (a, b) {
            let aText = $(a).text().toUpperCase();
            let bText = $(b).text().toUpperCase();
            return aText.localeCompare(bText);
        })

    $.each(sortedLiList, function (idx, li) {
        listContainer.append(li);
    });
}

function createWarnDivAndReturnOl(errorContainer) {
    let warnDiv = $("<div class=\"warnClass\">\n" +
        "<h3>Ostrze�enia:</h3>" +
        "<ol></ol>\n" +
        "</div>");
    errorContainer.prepend(warnDiv);
    return warnDiv.find("ol");
}

function checkAndCreateErrorDiv() {
    if ($(".errorFrame").length === 0) {
        $("<div class=\"errorFrame\"></div>").insertAfter($(".navigPositionDiv")[1]);
    }
}

function updateWarnList() {
    warnList.forEach((warn) => {
        addWarningToDOM(warn);
    });
}

function addWarning(warning) {
    if (!warnList.includes(warning) && !warnListPending.includes(warning)) {
        warnList.push(warning);
        if (document.readyState === 'complete') {
            addWarningToDOM(warning);
        } else {
            warnListPending.push(warning);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    checkAndCreateErrorDiv();
    let combinedSet = new Set([...warnList, ...warnListPending]);
    warnList = [...combinedSet];
    warnListPending = [];
    updateWarnList();
});

function getAjaxData(opisSkierowaniaDiv) {
    let data = {
        x_context: $(opisSkierowaniaDiv).attr("ajax_x_context"),
        x_sys_context: '',
        ajax_skierowanie_id: $(opisSkierowaniaDiv).attr("ajax_skierowanie_id"),
        ajax_bg_color: $(opisSkierowaniaDiv).attr("ajax_bg_color"),
        ajax_szczepienie_covid: $(opisSkierowaniaDiv).attr("ajax_szczepienie_covid"),
        ajax_sp_row_context: $(opisSkierowaniaDiv).attr("ajax_sp_row_context"),
        ajax_params_map: $(opisSkierowaniaDiv).attr("ajax_params_map")
    };

    JSON.parse($(opisSkierowaniaDiv).attr("ajax_parameter_map"))
        .forEach(element => {
            data[element.paramName] = element.paramValue;
        });

    return data;
}

function opisSkierowania(opisSkierowaniaDiv, attempt = 1) {
    let skierowanieId = $(opisSkierowaniaDiv).attr("ajax_skierowanie_id");

    $.ajax({
        url: 'app.ajax.skierowanielist.OpisSkierowania',
        method: 'GET',
        data: getAjaxData(opisSkierowaniaDiv),
        success: function (retrievedContent) {
            if (retrievedContent && retrievedContent.trim() !== "") {
                hideAjaxLouder(opisSkierowaniaDiv);
                let obj = jQuery.parseJSON(retrievedContent);
                $(opisSkierowaniaDiv).parent().html(obj.content);

                if (obj.warnList.length > 0) {
                    obj.warnList.forEach((warn) => addWarning(warn));
                }

                if (obj.showEdycjaOpisow) {
                    unhideLinkEdycjaOpisow(skierowanieId);
                } else {
                    hideLinkEdycjaOpisowLoader(skierowanieId);
                }
            } else if (attempt < 3) {
                setTimeout(() => {
                    opisSkierowania(opisSkierowaniaDiv, attempt + 1);
                }, 1000);
            } else {
                showErrorMessage(opisSkierowaniaDiv);
                hideLinkEdycjaOpisowLoader(skierowanieId);
            }
        },
        error: function (xhr, status, error) {
            if (xhr.status !== 200 && attempt < 3) {
                setTimeout(() => {
                    opisSkierowania(opisSkierowaniaDiv, attempt + 1);
                }, 1000);
            } else if (attempt >= 3) {
                showErrorMessage(opisSkierowaniaDiv);
                hideLinkEdycjaOpisowLoader(skierowanieId);
            }
        }
    });

    return false;
}

function unhideLinkEdycjaOpisow(skierowanieId) {
    let spanName = "#edycja_opisow_" + skierowanieId;
    let span = $(spanName);

    if (span.length > 0) {
        span.css("display", "");
        hideLinkEdycjaOpisowLoader(skierowanieId);
    } else {
        setTimeout(() => {
            unhideLinkEdycjaOpisow(skierowanieId);
        }, 100);
    }
}

function hideLinkEdycjaOpisowLoader(skierowanieId) {
    let imgName = "#edycja_opisow_ajax_loader_" + skierowanieId;
    let img = $(imgName);

    if (img.length > 0) {
        img.hide();
    } else {
        setTimeout(() => {
            hideLinkEdycjaOpisowLoader(skierowanieId);
        }, 100);
    }
}

function showErrorMessage(opisSkierowaniaDiv) {
    hideAjaxLouder(opisSkierowaniaDiv);
    $(opisSkierowaniaDiv).parent().append("Nie uda�o si� pobra� danych.");
}

function hideAjaxLouder(opisSkierowaniaDiv) {
    let img = $($(opisSkierowaniaDiv).parent()).children('img.ajax_loader');
    $(img).css('display', 'none');
}

function observeTableChanges() {
    let tbody = document;

    let observerSkierowania = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type == 'childList') {
                mutation.addedNodes.forEach((div) => {
                    if (div.nodeType === 1 && div.tagName === 'DIV') {
                        if (div.classList.contains('opis_skierowania_ajax')) {
                            opisSkierowania(div);
                        }
                    }
                });
            }
        });
    });

    let configOpisSkierowania = {childList: true, subtree: true, attributes: true};

    observerSkierowania.observe(tbody, configOpisSkierowania);
}

observeTableChanges();