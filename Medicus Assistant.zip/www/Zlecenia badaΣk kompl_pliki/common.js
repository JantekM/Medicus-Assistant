/** JS wspolne dla calej aplikacji, zalaczane przez TemplateServlet */

function isFloatKey(event) {
	var key = (event.which) ? event.which : event.keyCode;
	return (key == 37 || key == 38 || key == 39 || key == 40 || key == 8 || key == 46) ? true : (String.fromCharCode(key).match(/[0-9\.,]/g) ? true : false);
}

function isIntKey(event) {
	var key = (event.which) ? event.which : event.keyCode;
	return (key == 37 || key == 38 || key == 39 || key == 40 || key == 8 || key == 46) ? true : (String.fromCharCode(key).match(/[0-9]/g) ? true : false);
}

/**
 * input - element DOM !!! jesli uzywasz jquery to np. SelectAllText($('#selectme').first()[0]);
 */
function SelectAllText(input) {
    SelectText(input, 0, input.value.length);
}

/**
 *   np. SelectText($('#selectme').first()[0]); 
 */
function SelectText(input, startIdx, endIdx) {
    if ('selectionStart' in input) {
		input.selectionStart = startIdx;
		input.selectionEnd = endIdx;
		input.focus ();
	} else { // Internet Explorer before version 9
		var inputRange = input.createTextRange();
		inputRange.moveStart('character', startIdx);
		inputRange.collapse();
		inputRange.moveEnd('character', endIdx);
		inputRange.select();
	}
}

function focusField(fieldName){
	var fld = document.getElementsByName(fieldName);
	if(fld != null && fld[0] != null){
		fld[0].focus();
	}
}
