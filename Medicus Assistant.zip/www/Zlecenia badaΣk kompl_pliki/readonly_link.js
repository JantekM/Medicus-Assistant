/*function changeLinkToReadOnly(edwId) {
    var editLink = document.getElementById('p1statusInfoDiv' + edwId + '_editLink');
    editLink.textContent = 'Podgl�d'
}

function changeLinkToReadOnly(edwId, retrievedContent, link) {
    var editLink = document.getElementById('p1statusInfoDiv' + edwId + '_editLink');
    if (retrievedContent.includes('U REALIZATORA') || retrievedContent.includes('ZREALIZOWANE')) {
        editLink.textContent = 'Podgl�d'
        editLink.setAttribute('href', link)
    }
}

function changeLinkToReadOnly(edwId, retrievedContent, readOnlyHref, editHref) {
    var editLink = document.getElementById('p1statusInfoDiv' + edwId + '_editLink');
    if (retrievedContent.includes('U REALIZATORA') || retrievedContent.includes('ZREALIZOWANE')) {
        editLink.textContent = 'Podgl�d'
        editLink.setAttribute('href', readOnlyHref)
    } else if (retrievedContent.includes('WYSTAWIONE') ) {
        editLink.textContent = 'Edycja'
        editLink.setAttribute('href', editHref)
    }
}*/

function changeLinkToReadOnly(edwId, retrievedContent, readOnlyHref, editHref, idDokumentu) {
    // var editLink = document.getElementById('p1statusInfoDiv' + edwId + '_editLink');
    var generateLink = document.getElementById('hl7cda_generate_' + idDokumentu);
    if (retrievedContent.includes('U REALIZATORA') || retrievedContent.includes('ZREALIZOWANE')) {
        // editLink.textContent = 'Podgl�d'
        // editLink.setAttribute('href', readOnlyHref)
        generateLink.hidden = true
    } else if (retrievedContent.includes('WYSTAWIONE') ) {
        // editLink.textContent = 'Edycja'
        // editLink.setAttribute('href', editHref)
    }
}